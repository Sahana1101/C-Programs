#include <stdio.h>

int main()
{
    int n, i, j, found;

    printf("Enter size of array: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter array elements: ");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }

    int missing = 1;

    while(1)
    {
        found = 0;

        for(i = 0; i < n; i++)
        {
            if(arr[i] == missing)
            {
                found = 1;
                break;
            }
        }

        if(found == 0)
        {
            printf("First Missing Positive = %d", missing);
            break;
        }

        missing++;
    }

    return 0;
}
