#include <stdio.h>
#include <string.h>

int main()
{
    char str[100];
    int i, j, n;

    printf("Enter an odd length string: ");
    scanf("%s", str);

    n = strlen(str);

    if(n % 2 == 0)
    {
        printf("Please enter an odd length string.");
        return 0;
    }

    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            if(j == i || j == n - i - 1)
                printf("%c", str[j]);
            else
                printf(" ");
        }
        printf("\n");
    }

    return 0;
}
