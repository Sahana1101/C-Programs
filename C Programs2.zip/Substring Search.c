#include <stdio.h>
#include <string.h>

int substringSearch(char str[], char sub[])
{
    int i, j;

    int n = strlen(str);
    int m = strlen(sub);

    for(i = 0; i <= n - m; i++)
    {
        for(j = 0; j < m; j++)
        {
            if(str[i + j] != sub[j])
                break;
        }

        if(j == m)
            return i;
    }

    return -1;
}

int main()
{
    char str[100], sub[100];

    printf("Enter main string: ");
    scanf("%s", str);

    printf("Enter substring: ");
    scanf("%s", sub);

    int index = substringSearch(str, sub);

    if(index == -1)
        printf("Substring not found");
    else
        printf("Substring found at index %d", index);

    return 0;
}
