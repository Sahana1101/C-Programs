#include <stdio.h>
#include <string.h>

void reverse(char *str)
{
    char *space = strchr(str, ' ');

    if(space != NULL)
    {
        *space = '\0';
        reverse(space + 1);
        printf(" %s", str);
    }
    else
    {
        printf("%s", str);
    }
}

int main()
{
    char str[100];

    printf("Enter a sentence: ");
    fgets(str, sizeof(str), stdin);

    str[strcspn(str, "\n")] = '\0';

    reverse(str);

    return 0;
}
