#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int compare(const void *a, const void *b) {
    return (*(char *)a - *(char *)b);
}

void sortString(char str[], char sorted[]) {
    strcpy(sorted, str);
    qsort(sorted, strlen(sorted), sizeof(char), compare);
}

int main() {
    char words[][20] = {"eat", "tea", "tan", "ate", "nat", "bat"};
    int n = 6;

    char sortedWords[6][20];

    for (int i = 0; i < n; i++) {
        sortString(words[i], sortedWords[i]);
    }

    int visited[6] = {0};

    printf("Grouped Anagrams:\n");

    for (int i = 0; i < n; i++) {
        if (visited[i])
            continue;

        printf("[ ");
        printf("%s ", words[i]);
        visited[i] = 1;

        for (int j = i + 1; j < n; j++) {
            if (!visited[j] &&
                strcmp(sortedWords[i], sortedWords[j]) == 0) {
                printf("%s ", words[j]);
                visited[j] = 1;
            }
        }
        printf("]\n");
    }

    return 0;
}
