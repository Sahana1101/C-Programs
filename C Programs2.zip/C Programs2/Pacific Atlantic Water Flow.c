#include <stdio.h>

#define ROW 5
#define COL 5

int pacific[ROW][COL];
int atlantic[ROW][COL];

void dfs(int heights[ROW][COL], int visited[ROW][COL],
         int r, int c, int prev) {

    if (r < 0 || c < 0 || r >= ROW || c >= COL)
        return;

    if (visited[r][c])
        return;

    if (heights[r][c] < prev)
        return;

    visited[r][c] = 1;

    dfs(heights, visited, r + 1, c, heights[r][c]);
    dfs(heights, visited, r - 1, c, heights[r][c]);
    dfs(heights, visited, r, c + 1, heights[r][c]);
    dfs(heights, visited, r, c - 1, heights[r][c]);
}

int main() {

    int heights[ROW][COL] = {
        {1,2,2,3,5},
        {3,2,3,4,4},
        {2,4,5,3,1},
        {6,7,1,4,5},
        {5,1,1,2,4}
    };

    for (int i = 0; i < ROW; i++) {
        dfs(heights, pacific, i, 0, 0);
        dfs(heights, atlantic, i, COL - 1, 0);
    }

    for (int j = 0; j < COL; j++) {
        dfs(heights, pacific, 0, j, 0);
        dfs(heights, atlantic, ROW - 1, j, 0);
    }

    printf("Cells reaching both oceans:\n");

    for (int i = 0; i < ROW; i++) {
        for (int j = 0; j < COL; j++) {
            if (pacific[i][j] && atlantic[i][j])
                printf("(%d,%d)\n", i, j);
        }
    }

    return 0;
}
