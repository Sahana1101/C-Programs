#include <stdio.h>

int main()
{
    int n, i, j;

    printf("Enter size of array: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter array elements: ");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }

    for(i = 0; i < n; i++)
    {
        int found = 0;

        for(j = i + 1; j < n; j++)
        {
            if(arr[j] > arr[i])
            {
                printf("%d --> %d\n", arr[i], arr[j]);
                found = 1;
                break;
            }
        }

        if(found == 0)
        {
            printf("%d --> -1\n", arr[i]);
        }
    }

    return 0;
}
