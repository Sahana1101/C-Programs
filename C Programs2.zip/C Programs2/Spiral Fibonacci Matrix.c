#include <stdio.h>

int main() {
    int n = 3, m = 3;

    int total = n * m;
    int fib[100];
    int matrix[100][100];

    // Generate Fibonacci numbers
    fib[0] = 0;
    fib[1] = 1;

    for (int i = 2; i < total; i++) {
        fib[i] = fib[i - 1] + fib[i - 2];
    }

    int top = 0, bottom = n - 1;
    int left = 0, right = m - 1;
    int k = 0;

    while (top <= bottom && left <= right) {

        // Left to Right
        for (int i = left; i <= right; i++)
            matrix[top][i] = fib[k++];
        top++;

        // Top to Bottom
        for (int i = top; i <= bottom; i++)
            matrix[i][right] = fib[k++];
        right--;

        // Right to Left
        if (top <= bottom) {
            for (int i = right; i >= left; i--)
                matrix[bottom][i] = fib[k++];
            bottom--;
        }

        // Bottom to Top
        if (left <= right) {
            for (int i = bottom; i >= top; i--)
                matrix[i][left] = fib[k++];
            left++;
        }
    }

    printf("Spiral Fibonacci Matrix:\n");

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            printf("%4d ", matrix[i][j]);
        }
        printf("\n");
    }

    return 0;
}
