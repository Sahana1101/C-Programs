#include <stdio.h>
#include <string.h>

void reverse(char str[], int start, int end) {
    while (start < end) {
        char temp = str[start];
        str[start] = str[end];
        str[end] = temp;
        start++;
        end--;
    }
}

int main() {
    char s[100] = "(abcd)";
    int stack[100], top = -1;

    for (int i = 0; s[i] != '\0'; i++) {
        if (s[i] == '(')
            stack[++top] = i;
        else if (s[i] == ')') {
            int start = stack[top--];
            reverse(s, start + 1, i - 1);
        }
    }

    printf("%s\n", s);
    return 0;
}
