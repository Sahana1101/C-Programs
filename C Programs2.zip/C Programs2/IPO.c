#include <stdio.h>

int findMaxCapital(int k, int w, int profits[], int capital[], int n) {
    int used[n];
    for (int i = 0; i < n; i++)
        used[i] = 0;

    for (int i = 0; i < k; i++) {
        int maxProfit = -1;
        int idx = -1;

        for (int j = 0; j < n; j++) {
            if (!used[j] && capital[j] <= w) {
                if (profits[j] > maxProfit) {
                    maxProfit = profits[j];
                    idx = j;
                }
            }
        }

        if (idx == -1)
            break;

        w += profits[idx];
        used[idx] = 1;
    }

    return w;
}

int main() {
    int profits[] = {1, 2, 3};
    int capital[] = {0, 1, 1};

    printf("%d", findMaxCapital(2, 0, profits, capital, 3));
    return 0;
}
