#include <stdio.h>
#include <string.h>
#include <ctype.h>

void decodeString(char *s, char *result) {
    char strStack[100][100];
    int numStack[100];

    int strTop = -1, numTop = -1;
    char current[1000] = "";
    int num = 0;

    for (int i = 0; s[i] != '\0'; i++) {

        if (isdigit(s[i])) {
            num = num * 10 + (s[i] - '0');
        }

        else if (s[i] == '[') {
            numStack[++numTop] = num;
            strcpy(strStack[++strTop], current);

            num = 0;
            current[0] = '\0';
        }

        else if (s[i] == ']') {
            char temp[1000] = "";

            int repeat = numStack[numTop--];

            for (int j = 0; j < repeat; j++) {
                strcat(temp, current);
            }

            strcpy(current, strStack[strTop--]);
            strcat(current, temp);
        }

        else {
            int len = strlen(current);
            current[len] = s[i];
            current[len + 1] = '\0';
        }
    }

    strcpy(result, current);
}

int main() {
    char input[] = "3[a2[bc]]";
    char output[1000];

    decodeString(input, output);

    printf("Decoded String: %s\n", output);

    return 0;
}
