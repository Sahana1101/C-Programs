#include <stdio.h>
#include <string.h>

int main()
{
    char str[100];
    int k;

    printf("Enter string: ");
    scanf("%s", str);

    printf("Enter K: ");
    scanf("%d", &k);

    int n = strlen(str);
    int count = 0;

    for(int i = 0; i < n; i++)
    {
        int freq[256] = {0};
        int distinct = 0;

        for(int j = i; j < n; j++)
        {
            if(freq[(unsigned char)str[j]] == 0)
                distinct++;

            freq[(unsigned char)str[j]]++;

            if(distinct == k)
                count++;

            if(distinct > k)
                break;
        }
    }

    printf("Number of substrings = %d", count);

    return 0;
}
