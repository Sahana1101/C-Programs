#include <stdio.h>

int main()
{
    char str[100];
    int freq[256] = {0};
    int firstIndex[256];
    int i;

    for(i = 0; i < 256; i++)
        firstIndex[i] = -1;

    printf("Enter a string: ");
    scanf("%s", str);

    for(i = 0; str[i] != '\0'; i++)
    {
        unsigned char ch = str[i];

        freq[ch]++;

        if(firstIndex[ch] == -1)
            firstIndex[ch] = i;
    }

    int minIndex = 1000;

    for(i = 0; i < 256; i++)
    {
        if(freq[i] == 1 && firstIndex[i] < minIndex)
        {
            minIndex = firstIndex[i];
        }
    }

    if(minIndex == 1000)
        printf("No non-repeating character found");
    else
        printf("First non-repeating character = %c", str[minIndex]);

    return 0;
}
