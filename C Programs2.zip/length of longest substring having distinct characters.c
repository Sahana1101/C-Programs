#include <stdio.h>
#include <string.h>

int main()
{
    char str[100];
    int i, j, maxLen = 0;

    printf("Enter a string: ");
    scanf("%s", str);

    int len = strlen(str);

    for(i = 0; i < len; i++)
    {
        int visited[256] = {0};

        for(j = i; j < len; j++)
        {
            if(visited[(unsigned char)str[j]] == 1)
                break;

            visited[(unsigned char)str[j]] = 1;

            if(j - i + 1 > maxLen)
                maxLen = j - i + 1;
        }
    }

    printf("Length of Longest Distinct Substring = %d", maxLen);

    return 0;
}
