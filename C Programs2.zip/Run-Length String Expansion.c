#include <stdio.h>
#include <ctype.h>

int main()
{
    char str[100];

    printf("Enter encoded string: ");
    scanf("%s", str);

    int i = 0;

    while(str[i] != '\0')
    {
        char ch = str[i++];
        int count = 0;

        while(isdigit(str[i]))
        {
            count = count * 10 + (str[i] - '0');
            i++;
        }

        for(int j = 0; j < count; j++)
        {
            printf("%c", ch);
        }
    }

    return 0;
}
