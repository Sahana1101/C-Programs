#include <stdio.h>

int main()
{
    int n1, n2, i = 0, j = 0, k = 0;

    printf("Enter size of first array: ");
    scanf("%d", &n1);

    int arr1[n1];

    printf("Enter elements of first sorted array: ");
    for(int x = 0; x < n1; x++)
        scanf("%d", &arr1[x]);

    printf("Enter size of second array: ");
    scanf("%d", &n2);

    int arr2[n2];

    printf("Enter elements of second sorted array: ");
    for(int x = 0; x < n2; x++)
        scanf("%d", &arr2[x]);

    int result[n1 + n2];

    while(i < n1 && j < n2)
    {
        if(arr1[i] < arr2[j])
        {
            if(k == 0 || result[k-1] != arr1[i])
                result[k++] = arr1[i];
            i++;
        }
        else if(arr1[i] > arr2[j])
        {
            if(k == 0 || result[k-1] != arr2[j])
                result[k++] = arr2[j];
            j++;
        }
        else
        {
            if(k == 0 || result[k-1] != arr1[i])
                result[k++] = arr1[i];

            i++;
            j++;
        }
    }

    while(i < n1)
    {
        if(k == 0 || result[k-1] != arr1[i])
            result[k++] = arr1[i];
        i++;
    }

    while(j < n2)
    {
        if(k == 0 || result[k-1] != arr2[j])
            result[k++] = arr2[j];
        j++;
    }

    printf("Merged Array Without Duplicates:\n");

    for(i = 0; i < k; i++)
        printf("%d ", result[i]);

    return 0;
}
