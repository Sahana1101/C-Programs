#include <stdio.h>
#include <string.h>

int main()
{
    char str[100];
    int start = 0, maxLength = 1;
    int i, j, len;

    printf("Enter a string: ");
    scanf("%s", str);

    len = strlen(str);

    for(i = 0; i < len; i++)
    {
        // Check odd length palindrome
        int left = i;
        int right = i;

        while(left >= 0 && right < len &&
              str[left] == str[right])
        {
            if((right - left + 1) > maxLength)
            {
                start = left;
                maxLength = right - left + 1;
            }
            left--;
            right++;
        }

        // Check even length palindrome
        left = i;
        right = i + 1;

        while(left >= 0 && right < len &&
              str[left] == str[right])
        {
            if((right - left + 1) > maxLength)
            {
                start = left;
                maxLength = right - left + 1;
            }
            left--;
            right++;
        }
    }

    printf("Longest Palindromic Substring: ");

    for(i = start; i < start + maxLength; i++)
    {
        printf("%c", str[i]);
    }

    return 0;
}
