#include <stdio.h>
#include <string.h>

#define MAX 100

char stack[MAX];
int top = -1;

void push(char ch)
{
    stack[++top] = ch;
}

char pop()
{
    if(top == -1)
        return '\0';
    return stack[top--];
}

int main()
{
    char str[100];
    int i, valid = 1;

    printf("Enter parentheses string: ");
    scanf("%s", str);

    for(i = 0; str[i] != '\0'; i++)
    {
        char ch = str[i];

        if(ch == '(' || ch == '{' || ch == '[')
        {
            push(ch);
        }
        else if(ch == ')' || ch == '}' || ch == ']')
        {
            char x = pop();

            if((ch == ')' && x != '(') ||
               (ch == '}' && x != '{') ||
               (ch == ']' && x != '['))
            {
                valid = 0;
                break;
            }
        }
    }

    if(top != -1)
        valid = 0;

    if(valid)
        printf("Valid Parentheses");
    else
        printf("Invalid Parentheses");

    return 0;
}
