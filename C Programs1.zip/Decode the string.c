#include <stdio.h>

int main()
{
    char str[100];
    int i;

    printf("Enter encoded string: ");
    scanf("%s", str);

    for(i = 0; str[i] != '\0'; i++)
    {
        str[i] = str[i] - 1;
    }

    printf("Decoded string: %s", str);

    return 0;
}
