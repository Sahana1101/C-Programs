#include <stdio.h>
#include <pthread.h>

void *printOdd(void *arg)
{
    int i;
    for(i = 1; i <= 10; i += 2)
    {
        printf("Odd: %d\n", i);
    }
    return NULL;
}

void *printEven(void *arg)
{
    int i;
    for(i = 2; i <= 10; i += 2)
    {
        printf("Even: %d\n", i);
    }
    return NULL;
}

int main()
{
    pthread_t t1, t2;

    pthread_create(&t1, NULL, printOdd, NULL);
    pthread_create(&t2, NULL, printEven, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    return 0;
}
