#include <stdio.h>
#include <string.h>

int main()
{
    char str[100];
    int i, j;
    int maxLen = 0;

    printf("Enter a string: ");
    scanf("%s", str);

    int len = strlen(str);

    for(i = 0; i < len; i++)
    {
        int visited[256] = {0};

        for(j = i; j < len; j++)
        {
            if(visited[str[j]] == 1)
            {
                break;
            }

            visited[str[j]] = 1;

            if((j - i + 1) > maxLen)
            {
                maxLen = j - i + 1;
            }
        }
    }

    printf("Length of Longest Substring = %d", maxLen);

    return 0;
}
