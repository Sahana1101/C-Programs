#include <stdio.h>

int main()
{
    int n, i;

    printf("Enter number of days: ");
    scanf("%d", &n);

    int price[n];

    printf("Enter stock prices: ");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &price[i]);
    }

    int minPrice = price[0];
    int maxProfit = 0;

    for(i = 1; i < n; i++)
    {
        if(price[i] < minPrice)
        {
            minPrice = price[i];
        }

        int profit = price[i] - minPrice;

        if(profit > maxProfit)
        {
            maxProfit = profit;
        }
    }

    printf("Maximum Profit = %d", maxProfit);

    return 0;
}
