#include <stdio.h>

int main()
{
    int n, i;
    int arr[100];
    int totalSum = 0, leftSum = 0;

    printf("Enter size of array: ");
    scanf("%d", &n);

    printf("Enter array elements: ");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
        totalSum += arr[i];
    }

    for(i = 0; i < n; i++)
    {
        totalSum = totalSum - arr[i];

        if(leftSum == totalSum)
        {
            printf("Equilibrium point = %d\n", arr[i]);
            printf("Position = %d", i);
            return 0;
        }

        leftSum += arr[i];
    }

    printf("No Equilibrium Point Found");

    return 0;
}
