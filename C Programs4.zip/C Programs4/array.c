#include<stdio.h>
int main()
{
    int arr[2]={1,2,3};
    arr[0]=5;
    printf("%d",arr[0]);
    return 0;
}
