#include <stdio.h>
#include <string.h>

void interpret(char command[]) {
    char result[100];
    int j = 0;

    for (int i = 0; command[i] != '\0'; ) {

        if (command[i] == 'G') {
            result[j++] = 'G';
            i++;
        }
        else if (command[i] == '(' && command[i + 1] == ')') {
            result[j++] = 'o';
            i += 2;
        }
        else if (strncmp(&command[i], "(al)", 4) == 0) {
            result[j++] = 'a';
            result[j++] = 'l';
            i += 4;
        }
    }

    result[j] = '\0';

    printf("Output: %s\n", result);
}

int main() {
    char command[] = "G()(al)";

    interpret(command);

    return 0;
}
