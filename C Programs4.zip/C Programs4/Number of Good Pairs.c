#include <stdio.h>

int numIdenticalPairs(int nums[], int n) {
    int freq[101] = {0};
    int count = 0;

    for (int i = 0; i < n; i++) {
        count += freq[nums[i]];
        freq[nums[i]]++;
    }

    return count;
}
