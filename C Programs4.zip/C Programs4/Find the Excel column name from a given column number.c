#include <stdio.h>
#include <string.h>

void columnName(int n) {
    char result[100];
    int index = 0;

    while (n > 0) {
        n--;

        result[index++] = 'A' + (n % 26);

        n /= 26;
    }

    result[index] = '\0';

    // Reverse the string
    for (int i = 0, j = index - 1; i < j; i++, j--) {
        char temp = result[i];
        result[i] = result[j];
        result[j] = temp;
    }

    printf("Excel Column Name: %s\n", result);
}

int main() {
    int n = 703;

    columnName(n);

    return 0;
}
