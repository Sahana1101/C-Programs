#include <stdio.h>
#include <math.h>

int main() {
    float a, b, c, d, root1, root2;

    printf("Enter a, b, c: ");
    scanf("%f %f %f", &a, &b, &c);

    d = b * b - 4 * a * c;

    if(d > 0) {
        root1 = (-b + sqrt(d)) / (2 * a);
        root2 = (-b - sqrt(d)) / (2 * a);

        printf("Roots = %.2f and %.2f", root1, root2);
    }
    else if(d == 0) {
        root1 = -b / (2 * a);

        printf("Equal Roots = %.2f", root1);
    }
    else {
        printf("Imaginary Roots");
    }

    return 0;
}
