#include <stdio.h>

int isPrime(int num) {
    if (num < 2)
        return 0;

    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0)
            return 0;
    }

    return 1;
}

int main() {
    int n = 10;
    int sum = 0;

    for (int i = 2; i <= n; i++) {
        if (isPrime(i))
            sum += i;
    }

    printf("Sum of primes = %d\n", sum);

    return 0;
}
