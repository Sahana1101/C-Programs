#include <stdio.h>

int main() {
    int n, prime = 1;

    printf("Enter a number: ");
    scanf("%d", &n);

    if(n <= 1)
        prime = 0;

    for(int i = 2; i * i <= n; i++) {
        if(n % i == 0) {
            prime = 0;
            break;
        }
    }

    if(prime)
        printf("Prime Number");
    else
        printf("Not Prime Number");

    return 0;
}
